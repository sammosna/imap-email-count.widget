# imap-email-count.widget

Since I've not found any widget that gets unread messages through IMAP..

## Screenshots
![Normal Display](https://raw.githubusercontent.com/sammosna/imap-email-count.widget/master/screenshot.png)

## Getting started
Edit `scripts/imap.py` and you are ready to go!

## Roadmap
- [ ] Configuration and personalization
- [ ] Get message sender and preview